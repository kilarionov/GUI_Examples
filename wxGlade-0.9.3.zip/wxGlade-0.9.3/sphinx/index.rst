.. wxGlade documentation master file, created by
   sphinx-quickstart on Sun Oct  8 22:11:32 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.


.. |wxglade| image:: images/wxglade.png
    :alt: wxGlade title


|wxglade| Welcome to wxGlade's documentation!
=============================================



.. image:: images/wxglade_large.png
    :alt: wxGlade title


.. toctree::
   :maxdepth: 3
   :caption: Contents:
   
   intro
   wxbasics
   tutorial
   source_code
   menu_status_tool
   bitmaps
   custom_widgets
   reference
   further_reading
   acknowledgements

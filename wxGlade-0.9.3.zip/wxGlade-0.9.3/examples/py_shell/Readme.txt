This (Python only) example shows how to use the Custom Widget to include a
Python shell from the wx.py.shell.Shell module.
The application is available in the shell through the variable 'app'.


 - the property "Class" is set to "wx.py.shell.Shell"
 - on the "Widget" page, the argument introText is used to provide a welcome message
 - on the "Code" page, the first property ensures that wx.py.shell is imported
